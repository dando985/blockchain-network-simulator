#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <algorithm>
#include <cmath>
#include <cctype>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <vector>

// Hardcoded host address for all components to connect to
static const char *TXCHAIN_HOST = "127.0.0.1";

// Structure to represent a transaction record
struct TxRecord {
    int serial = 0;
    std::string sender;
    std::string receiver;
    std::string amount;
};

// Trim whitespace from both ends of a string
inline std::string trim(const std::string &s) {
    size_t b = s.find_first_not_of(" \t\r\n");
    if (b == std::string::npos) {
        return "";
    }

    size_t e = s.find_last_not_of(" \t\r\n");

    return s.substr(b, e - b + 1);
}

// Encryption shift logic for alphanumeric characters
inline char shift_char(char c, int shift) {

    // Shift lowercase letters
    if (c >= 'a' && c <= 'z') {
        int base = 'a';
        int x = (c - base + shift) % 26;
        if (x < 0) x += 26;
        return static_cast<char>(base + x);
    }

    // Shift uppercase letters
    if (c >= 'A' && c <= 'Z') {
        int base = 'A';
        int x = (c - base + shift) % 26;
        if (x < 0) x += 26;
        return static_cast<char>(base + x);
    }

    // Shift digits
    if (c >= '0' && c <= '9') {
        int base = '0';
        int x = (c - base + shift) % 10;
        if (x < 0) x += 10;
        return static_cast<char>(base + x);
    }
    return c;
}

// Helper to perform per-letter shift in a string for encryption and decryption
inline std::string letter_shift(const std::string &text, int shift) {
    std::string out;
    out.reserve(text.size());
    for (char c : text) {
        out.push_back(shift_char(c, shift));
    }

    return out;
}

// Encrypt text with a shift of 3
inline std::string encrypt_text(const std::string &text) {
    return letter_shift(text, 3);
}

// Decrypt text with a shift of -3
inline std::string decrypt_text(const std::string &text) {
    return letter_shift(text, -3);
}

// Removes trailing zeros and unnecessary decimal point from a formatted amount string
inline std::string format_amount(double value) {
    double rounded = std::round(value);

    if (std::fabs(value - rounded) < 1e-9) {
        long long n = static_cast<long long>(rounded);
        return std::to_string(n);
    }

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(10) << value;
    std::string s = oss.str();

    while (!s.empty() && s.find('.') != std::string::npos && s.back() == '0') {
        s.pop_back();
    }

    if (!s.empty() && s.back() == '.') {
        s.pop_back();
    }

    return s;
}

// Converts amount string to double for computation
inline bool parse_amount(const std::string &s, double &out) {
    try {
        size_t idx = 0;
        out = std::stod(s, &idx);
        return idx == s.size();
    } catch (...) {
        return false;
    }
}

// Convert block file record line to TxRecord structure
inline bool parse_record_line(const std::string &line, TxRecord &rec) {
    std::istringstream iss(line);
    if (!(iss >> rec.serial >> rec.sender >> rec.receiver >> rec.amount)) {
        return false;
    }

    return true;
}

// Convert TxRecord structure to a string for block file storage
inline std::string record_to_line(const TxRecord &rec) {
    std::ostringstream oss;
    oss << rec.serial << ' ' << rec.sender << ' ' << rec.receiver << ' ' << rec.amount;

    return oss.str();
}

// Helper function to read a block file and return a vector of TxRecord structures
inline std::vector<TxRecord> parse_records_text(const std::string &text) {
    std::vector<TxRecord> records;
    std::istringstream iss(text);
    std::string line;

    // Split the text into lines, trim whitespace, and parse each line into a TxRecord structure
    while (std::getline(iss, line)) {
        line = trim(line);
        if (line.empty()) continue;
        TxRecord enc;
        if (!parse_record_line(line, enc)) continue;
        TxRecord rec;
        rec.serial = enc.serial;
        rec.sender = decrypt_text(enc.sender);
        rec.receiver = decrypt_text(enc.receiver);
        rec.amount = decrypt_text(enc.amount);
        records.push_back(rec);
    }

    return records;
}

// Converts a vector of TxRecord structures to an encrypted string
inline std::string records_to_text(const std::vector<TxRecord> &records, bool encrypt_fields) {
    std::ostringstream oss;

    for (size_t i = 0; i < records.size(); ++i) {
        const auto &r = records[i];
        oss << r.serial << ' '
            << (encrypt_fields ? encrypt_text(r.sender) : r.sender) << ' '
            << (encrypt_fields ? encrypt_text(r.receiver) : r.receiver) << ' '
            << (encrypt_fields ? encrypt_text(r.amount) : r.amount);
        if (i + 1 < records.size()) oss << '\n';
    }

    return oss.str();
}

// Reads the entire content of a file and returns it as a string
inline std::string load_file_text(const std::string &path) {
    std::ifstream ifs(path);
    if (!ifs.is_open()) {
        return "";
    }

    std::ostringstream oss;
    oss << ifs.rdbuf();

    return oss.str();
}

// Loads a block file, parses its content, and returns a vector of TxRecord structures
inline std::vector<TxRecord> load_records_from_file(const std::string &path) {
    return parse_records_text(load_file_text(path));
}

// Saves a vector of TxRecord structures to a block file with encryption when new transactions are added
inline void save_records_to_file(const std::string &path, const std::vector<TxRecord> &records, bool encrypt_fields) {
    std::ofstream ofs(path, std::ios::trunc);
    for (size_t i = 0; i < records.size(); ++i) {
        const auto &r = records[i];
        ofs << r.serial << ' '
            << (encrypt_fields ? encrypt_text(r.sender) : r.sender) << ' '
            << (encrypt_fields ? encrypt_text(r.receiver) : r.receiver) << ' '
            << (encrypt_fields ? encrypt_text(r.amount) : r.amount);
        ofs << '\n';
    }
}

// Creates a set of all users
inline std::set<std::string> participant_set(const std::vector<TxRecord> &records) {
    std::set<std::string> out;
    for (const auto &r : records) {
        out.insert(r.sender);
        out.insert(r.receiver);
    }

    return out;
}

// Calculates the balance of a user by iterating through all transaction records
inline double compute_balance(const std::vector<TxRecord> &records, const std::string &username) {
    // Starting balance for all users
    double balance = 1000.0;

    // Iterate through all transaction records and update the balance based on sent and received amounts
    for (const auto &r : records) {
        double amount = 0.0;
        if (!parse_amount(r.amount, amount)) continue;
        if (r.sender == username) balance -= amount;
        if (r.receiver == username) balance += amount;
    }

    return balance;
}

// Finds last serial number among all transaction records to assign the next serial for a new transaction
inline int max_serial(const std::vector<TxRecord> &records) {
    int m = 0;
    for (const auto &r : records) m = std::max(m, r.serial);
    return m;
}

// Handles CHECK request by collecting all transaction records and computing the balance for the requested user
inline std::string build_response_for_check(const std::vector<TxRecord> &all_records, const std::string &username) {
    auto participants = participant_set(all_records);

    // Handle case where the requested user is not part of the network
    if (participants.find(username) == participants.end()) {
        std::ostringstream oss;
        oss << "\"" << username << "\" is not a part of the network.\n";

        return oss.str();
    }

    // Otherwise compute and return the balance for the requested user
    std::ostringstream oss;
    oss << "The current balance of \"" << username << "\" is : " << format_amount(compute_balance(all_records, username)) << " txcoins.\n";

    return oss.str();
}

// Handles TX request by validating the transaction details and computing the resulting balance for the sender after the transaction
inline std::string build_response_for_tx(const std::vector<TxRecord> &all_records,
                                         const std::string &sender,
                                         const std::string &receiver,
                                         const std::string &amount_text,
                                         bool &success,
                                         double &sender_balance_after,
                                         std::string &reason) {
    auto participants = participant_set(all_records);
    bool sender_exists = participants.find(sender) != participants.end();
    bool receiver_exists = participants.find(receiver) != participants.end();

    // Handle case where both users do not exist in the network
    if (!sender_exists && !receiver_exists) {
        success = false;
        reason = "both_missing";
        std::ostringstream oss;
        oss << "Unable to proceed with the transaction as \"" << sender << "\" and \"" << receiver << "\" are not part of the network.\n";
        return oss.str();
    }

    // Handle case where sender does not exist in the network
    if (!sender_exists) {
        success = false;
        reason = "sender_missing";
        std::ostringstream oss;
        oss << "Unable to proceed with the transaction as \"" << sender << "\" is not part of the network.\n";
        return oss.str();
    }

    // Handle case where receiver does not exist in the network
    if (!receiver_exists) {
        success = false;
        reason = "receiver_missing";
        std::ostringstream oss;
        oss << "Unable to proceed with the transaction as \"" << receiver << "\" is not part of the network.\n";
        return oss.str();
    }

    // Parse the amount, validate the sender's balance, and compute the resulting balance after the transaction.
    double amount = 0.0;
    if (!parse_amount(amount_text, amount)) amount = 0.0;
    double sender_balance = compute_balance(all_records, sender);
    sender_balance_after = sender_balance - amount;

    // Handle case where sender has insufficient balance for the transaction
    if (sender_balance + 1e-9 < amount) {
        success = false;
        reason = "insufficient";
        std::ostringstream oss;
        oss << "\"" << sender << "\" was unable to transfer " << amount_text << " txcoins to \"" << receiver << "\" because of insufficient balance.\n\n";
        oss << "The current balance of \"" << sender << "\" is : " << format_amount(sender_balance) << " txcoins.\n";

        return oss.str();
    }

    // Handle case where the transaction is valid and successful
    success = true;
    reason = "success";
    std::ostringstream oss;
    oss << "\"" << sender << "\" successfully transferred " << amount_text << " txcoins to \"" << receiver << "\".\n\n";
    oss << "The current balance of \"" << sender << "\" is : " << format_amount(sender_balance_after) << " txcoins.\n";
    return oss.str();
}

// Creates a TCP server socket, binds it to the specified port, and starts listening for incoming connections
inline int open_tcp_server_socket(int port) {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // Exit if socket creation fails
    if (sockfd < 0) {
        perror("socket");
        exit(1);
    }

    // Allow reuse of the address to avoid any errors when restarting the server
    int yes = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    sockaddr_in servaddr{};
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(TXCHAIN_HOST);
    servaddr.sin_port = htons(port);

    // Bind socket and exit if there is an error
    if (bind(sockfd, reinterpret_cast<sockaddr*>(&servaddr), sizeof(servaddr)) < 0) {
        perror("bind");
        exit(1);
    }

    // Start listening for incoming connections and exit if there is an error
    if (listen(sockfd, 10) < 0) {
        perror("listen");
        exit(1);
    }

    return sockfd;
}

// Creates a TCP client socket and binds it to a dynamic port
inline int open_tcp_client_socket() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // Exit if socket creation fails
    if (sockfd < 0) {
        perror("socket");
        exit(1);
    }

    // Allow reuse of the address to avoid any errors when restarting the client
    int yes = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(TXCHAIN_HOST);
    addr.sin_port = htons(0);

    // Bind socket and exit if there is an error
    if (bind(sockfd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
        perror("bind");
        exit(1);
    }

    return sockfd;
}

// Returns the dynamic port number assigned to a TCP socket
inline int get_local_tcp_port(int sockfd) {
    sockaddr_in addr{};
    socklen_t len = sizeof(addr);

    // Get the local address and port number assigned to the socket and exit if there is an error
    if (getsockname(sockfd, reinterpret_cast<sockaddr*>(&addr), &len) < 0) {
        return -1;
    }

    return ntohs(addr.sin_port);
}

// Keeps receiving data from a TCP socket until the connection is closed
inline std::string recv_all_tcp(int sockfd) {
    std::string out;
    char buf[4096];
    while (true) {
        ssize_t n = recv(sockfd, buf, sizeof(buf), 0);
        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        if (n == 0) {
            break;
        }
        out.append(buf, buf + n);
    }

    return out;
}

// Ensures that all data is sent over a TCP socket
inline void send_all_tcp(int sockfd, const std::string &data) {
    size_t sent = 0;
    while (sent < data.size()) {
        ssize_t n = send(sockfd, data.data() + sent, data.size() - sent, 0);
        if (n < 0) {
            if (errno == EINTR) continue;
            return;
        }
        sent += static_cast<size_t>(n);
    }
}

// Splits a string into lines, trimming whitespace and ignoring empty lines
inline std::vector<std::string> split_lines(const std::string &text) {
    std::vector<std::string> lines;
    std::istringstream iss(text);
    std::string line;

    while (std::getline(iss, line)) {
        line = trim(line);
        if (!line.empty()) {
            lines.push_back(line);
        }
    }

    return lines;
}

// Helper to create a chunk packet with the specified type, sequence number, total chunks, and payload
inline std::string chunk_packet(const std::string &type, int seq, int total, const std::string &payload) {
    std::ostringstream oss;
    oss << type << '|' << seq << '|' << total << '|' << payload;

    return oss.str();
}

// Parses a chunk packet into its components: type, sequence number, total chunks, and payload
inline bool parse_chunk_packet(const std::string &packet, std::string &type, int &seq, int &total, std::string &payload) {

    // The packet format is: type|seq|total|payload
    size_t p1 = packet.find('|');
    if (p1 == std::string::npos) {
        return false;
    }

    size_t p2 = packet.find('|', p1 + 1);
    if (p2 == std::string::npos) {
        return false;
    }

    size_t p3 = packet.find('|', p2 + 1);
    if (p3 == std::string::npos) {
        return false;
    }

    type = packet.substr(0, p1);
    try {
        seq = std::stoi(packet.substr(p1 + 1, p2 - p1 - 1));
        total = std::stoi(packet.substr(p2 + 1, p3 - p2 - 1));
    } catch (...) {
        return false;
    }
    payload = packet.substr(p3 + 1);

    return true;
}

// Sends a request via UDP and waits for the response
inline std::string udp_request_response(int sockfd, const sockaddr_in &dest, const std::string &request) {

    // Send the request packet to the destination and exit if there is an error
    if (sendto(sockfd, request.data(), request.size(), 0, reinterpret_cast<const sockaddr*>(&dest), sizeof(dest)) < 0) {
        perror("sendto");
        return "";
    }

    std::map<int, std::string> chunks;
    int total = -1;

    // Keep receiving chunk packets until all chunks have been received, and then reassemble the payload in the correct order
    while (total == -1 || static_cast<int>(chunks.size()) < total) {
        char buf[2048];
        sockaddr_in from{};
        socklen_t fromlen = sizeof(from);
        ssize_t n = recvfrom(sockfd, buf, sizeof(buf), 0, reinterpret_cast<sockaddr*>(&from), &fromlen);
        if (n < 0) {
            if (errno == EINTR) continue;
            perror("recvfrom");
            break;
        }
        std::string packet(buf, buf + n);
        std::string type, payload;
        int seq = 0, tot = 0;
        if (!parse_chunk_packet(packet, type, seq, tot, payload)) {
            continue;
        }

        if (total == -1) {
            total = tot;
        }

        chunks[seq] = payload;
    }
    std::string out;
    for (int i = 1; i <= total; ++i) {
        out += chunks[i];
    }

    return out;
}

// Helper to send a large payload in smaller chunks over UDP
inline void udp_send_all_chunks(int sockfd, const sockaddr_in &dest, const std::string &type, const std::string &payload) {
    const size_t CHUNK = 1100;
    size_t total = payload.empty() ? 1 : ((payload.size() + CHUNK - 1) / CHUNK);
    for (size_t i = 0; i < total; ++i) {
        std::string part;
        if (!payload.empty()) {
            size_t start = i * CHUNK;
            size_t len = std::min(CHUNK, payload.size() - start);
            part = payload.substr(start, len);
        }
        std::string packet = chunk_packet(type, static_cast<int>(i + 1), static_cast<int>(total), part);
        sendto(sockfd, packet.data(), packet.size(), 0, reinterpret_cast<const sockaddr*>(&dest), sizeof(dest));
    }
}

#endif
